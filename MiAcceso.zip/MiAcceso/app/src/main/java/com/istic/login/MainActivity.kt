package com.istic.login

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.ComponentActivity

class MainActivity : ComponentActivity() {

    val usuario = "admin"
    val clave = "1234"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val etUsuario = findViewById<EditText>(R.id.etUsuario)
        val etPassword = findViewById<EditText>(R.id.etClave)
        val btIngresar = findViewById<Button>(R.id.btIngresar)
        val tvErrorAcceso = findViewById<TextView>(R.id.tvErrorAcceso)




        btIngresar.setOnClickListener {

            val usuarioIngresado = etUsuario.text.toString()
            val claveIngresada = etPassword.text.toString()

            Log.w("UsuarioIngresado=",usuarioIngresado)
            Log.w("claveIngresada=",claveIngresada)
            Log.w("usuario=",usuario)
            Log.w("clave=",clave)
            if(usuarioIngresado == usuario
                && claveIngresada == clave){
                //Acá va a otra actividad
                val intent = Intent(this,OtraActivity::class.java)
                intent.putExtra("usuario",usuarioIngresado)
                startActivity(intent)
            }else{
                //error de acceso
                tvErrorAcceso.text ="Su usuario o contraseña son incorrectos"
            }
        }

    }
}