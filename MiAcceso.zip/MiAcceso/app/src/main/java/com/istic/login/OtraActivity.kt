package com.istic.login

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Spinner
import android.widget.TextView

class OtraActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_otra)
        val tvSaludo = findViewById<TextView>(R.id.tvSaludo)

        val spMonedas = findViewById<Spinner>(R.id.spMonedas)

        val monedas = listOf("Dolar", "Pesos Argentinos","Euros")

        val adapter      = ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,monedas)
        spMonedas.adapter = adapter

        tvSaludo.text = "Bienvenido " + intent.getStringExtra("usuario")



    }
}